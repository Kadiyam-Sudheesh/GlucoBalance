"""
Data models for GlucoBalance health assistant.
"""
from dataclasses import dataclass
from datetime import date, datetime
from typing import Optional, List, Dict
from enum import Enum
from flask_sqlalchemy import SQLAlchemy

# Initialize SQLAlchemy instance
db = SQLAlchemy()

class DiabetesType(Enum):
    TYPE_1 = "Type 1"
    TYPE_2 = "Type 2"
    PRE_DIABETIC = "Pre-diabetic"
    GESTATIONAL = "Gestational"


class ProgressStatus(Enum):
    IMPROVING_STEADILY = "Improving steadily"
    STABLE_CONTROLLED = "Stable and controlled"
    NEEDS_ADJUSTMENT = "Needs lifestyle adjustment"


# --- SQLAlchemy Models for Persistence ---

class User(db.Model):
    """User database model."""
    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(120), unique=True, nullable=False)
    phone = db.Column(db.String(20), nullable=True) # Optional if email is primary, but app treats them similarly
    password = db.Column(db.String(200), nullable=False)
    name = db.Column(db.String(100), nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    last_login = db.Column(db.DateTime, nullable=True)
    
    # Profile fields stored directly on User for simplicity
    age = db.Column(db.Integer, nullable=True)
    diabetes_type = db.Column(db.String(50), default="TYPE_2")
    height_cm = db.Column(db.Float, nullable=True)
    weight_kg = db.Column(db.Float, nullable=True)

    # Relationships
    reports = db.relationship('Report', backref='user', lazy=True)

    def to_profile_dict(self):
        """Convert to dictionary for profile."""
        return {
            "name": self.name,
            "age": self.age,
            "diabetes_type": self.diabetes_type,
            "height_cm": self.height_cm,
            "weight_kg": self.weight_kg
        }

class Report(db.Model):
    """Health Report database model."""
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    
    fbs = db.Column(db.Float, nullable=False)
    ppbs = db.Column(db.Float, nullable=False)
    hba1c = db.Column(db.Float, nullable=False)
    test_date = db.Column(db.Date, nullable=False, default=date.today)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)
    notes = db.Column(db.Text, nullable=True)

    def to_dict(self):
        """Convert to dictionary."""
        return {
            "id": self.id,
            "fbs": self.fbs,
            "ppbs": self.ppbs,
            "hba1c": self.hba1c,
            "test_date": self.test_date.isoformat(),
            "timestamp": self.timestamp.isoformat() if self.timestamp else None,
            "notes": self.notes
        }


# --- Dataclasses for Analysis/API Logic (Keep as is) ---

@dataclass
class UserProfile:
    """User profile information."""
    age: int
    diabetes_type: DiabetesType
    height_cm: float
    weight_kg: float
    name: Optional[str] = None


@dataclass
class HealthReport:
    """Health report with blood sugar measurements."""
    fbs: float  # Fasting Blood Sugar (mg/dL)
    ppbs: float  # Post-Prandial Blood Sugar (mg/dL)
    hba1c: float  # HbA1c (%)
    test_date: date
    notes: Optional[str] = None


@dataclass
class DailyReading:
    """Daily sugar reading entry."""
    date: date
    fasting_sugar: Optional[float] = None
    post_meal_sugar: Optional[float] = None
    activity_minutes: Optional[int] = None
    diet_adherence_score: Optional[float] = None  # 0-10 scale
    notes: Optional[str] = None


@dataclass
class WeeklyProgress:
    """Weekly progress data."""
    week_start_date: date
    daily_readings: List[DailyReading]
    average_fasting: Optional[float] = None
    average_post_meal: Optional[float] = None
    total_activity_minutes: Optional[int] = None
    average_diet_score: Optional[float] = None


@dataclass
class MonthlySummary:
    """Monthly summary data."""
    month: int
    year: int
    weekly_progresses: List[WeeklyProgress]
    health_reports: List[HealthReport]
    average_fbs: Optional[float] = None
    average_ppbs: Optional[float] = None
    average_hba1c: Optional[float] = None


@dataclass
class AnalysisContext:
    """Context for analysis containing all relevant data."""
    user_profile: UserProfile
    current_report: HealthReport
    previous_report: Optional[HealthReport]
    weekly_progress: Optional[WeeklyProgress]
    monthly_summary: Optional[MonthlySummary]
    historical_reports: List[HealthReport] = None
    historical_weekly_data: List[WeeklyProgress] = None
