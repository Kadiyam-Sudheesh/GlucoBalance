"""
GlucoBalance Web App
Clean, professional UI for the GlucoBalance digital health assistant.
"""

from datetime import date, datetime, timedelta
import os
import json

from flask import Flask, render_template, request, redirect, url_for, session, flash

from api import GlucoBalanceAPI
from models import db, User, Report
from deep_translator import GoogleTranslator

def create_app() -> Flask:
    """Application factory."""
    app = Flask(__name__)
    app.config["SECRET_KEY"] = "glucobalance-demo-secret-key"
    
    # Database Configuration
    # Use SQLite. db file will be created in the instance folder or current folder.
    basedir = os.path.abspath(os.path.dirname(__file__))
    app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///' + os.path.join(basedir, 'glucocare.db')
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

    # Initialize extensions
    db.init_app(app)
    api = GlucoBalanceAPI()

    # Create tables within app context
    with app.app_context():
        db.create_all()

    # Add custom Jinja2 filter for strftime
    def strftime_filter(fmt: str) -> str:
        """Format the current datetime using strftime."""
        return datetime.now().strftime(fmt)

    app.jinja_env.filters["strftime"] = strftime_filter

    @app.route("/", methods=["GET"])
    def index():
        """Landing page."""
        return render_template("index.html")

    @app.route("/login", methods=["GET", "POST"])
    def login():
        """Login page and handler."""
        if request.method == "POST":
            email = request.form.get("email", "").strip()
            email = request.form.get("email", "").strip()
            phone = request.form.get("phone", "").strip()
            country_code = request.form.get("country_code", "+91").strip()
            password = request.form.get("password", "").strip()
            
            # Validate at least one login credential is provided
            if not email and not phone:
                flash("Please enter either email address or phone number", "error")
                return redirect(url_for("login"))
            
            if not password:
                flash("Please enter your password", "error")
                return redirect(url_for("login"))
            
            # Determine login identifier (prefer email, fallback to phone)
            login_identifier = None
            if email:
                login_identifier = email
            elif phone:
                # Clean phone number (remove spaces, dashes)
                clean_phone = phone.replace(" ", "").replace("-", "")
                
                # If user typed a full international number (starts with +), ignore the dropdown
                if clean_phone.startswith("+"):
                     login_identifier = clean_phone
                else:
                     login_identifier = f"{country_code}{clean_phone}"

            # Check if user exists and password matches
            user = None
            if email:
                user = User.query.filter_by(email=email).first()
            elif phone:
                # Try finding user with the constructed phone number
                user = User.query.filter_by(phone=login_identifier).first()
                
                # Fallback: If not found, try without country code prefix just in case (though unlikely with current signup logic)
                if not user and not clean_phone.startswith("+"):
                    # Maybe they registered without country code? (Legacy data)
                    user = User.query.filter_by(phone=clean_phone).first()
            
            if user and user.password == password:
                # Login successful - set session
                session["user_id"] = user.id
                session["user_email"] = user.email
                session["user_name"] = user.name
                
                # Update last login timestamp
                user.last_login = datetime.utcnow()
                db.session.commit()
                
                flash(f"Welcome back, {user.name or 'User'}!", "success")
                return redirect(url_for("dashboard"))
            else:
                flash("Invalid credentials. Please try again.", "error")
                return redirect(url_for("login"))
        
        return render_template("login.html")

    @app.route("/signup", methods=["GET", "POST"])
    def signup():
        """Sign up page and handler."""
        if request.method == "POST":
            name = request.form.get("name", "").strip()
            email = request.form.get("email", "").strip()
            phone = request.form.get("phone", "").strip()
            country_code = request.form.get("country_code", "+91").strip()
            password = request.form.get("password", "").strip()
            confirm_password = request.form.get("confirm_password", "").strip()
            terms = request.form.get("terms")
            
            # Validate all required fields
            if not all([name, email, phone, country_code, password, confirm_password, terms]):
                flash("All fields are mandatory", "error")
                return redirect(url_for("signup"))
            
            if password != confirm_password:
                flash("Passwords do not match", "error")
                return redirect(url_for("signup"))
            
            if len(password) < 6:
                flash("Password must be at least 6 characters", "error")
                return redirect(url_for("signup"))
            
            # Check if user already exists
            existing_user = User.query.filter_by(email=email).first()
            if existing_user:
                flash("Email already registered. Please login.", "error")
                return redirect(url_for("signup"))
            
            # Create new user
            new_user = User(
                name=name,
                email=email,
                phone=f"{country_code}{phone}",
                password=password
            )
            db.session.add(new_user)
            db.session.commit()
            
            session["user_id"] = new_user.id
            session["user_email"] = new_user.email
            session["user_name"] = new_user.name
            flash("Account created successfully! Welcome to GlucoBalance.", "success")
            return redirect(url_for("analyze"))
        
        return render_template("signup.html")

    @app.route("/logout", methods=["GET"])
    def logout():
        """Logout user."""
        session.clear()
        flash("You have been logged out", "info")
        return redirect(url_for("index"))

    @app.route("/delete_report/<int:report_id>", methods=["POST"])
    def delete_report(report_id):
        """Delete a specific report."""
        if "user_id" not in session:
            flash("Please login to delete reports", "error")
            return redirect(url_for("login"))
            
        report = Report.query.get_or_404(report_id)
        
        # Verify ownership
        if report.user_id != session["user_id"]:
            flash("You do not have permission to delete this report", "error")
            return redirect(url_for("dashboard"))
            
        try:
            db.session.delete(report)
            db.session.commit()
            flash("Report deleted successfully", "success")
        except Exception as e:
            db.session.rollback()
            flash("Error deleting report", "error")
            
        return redirect(url_for("dashboard"))

    @app.route("/edit_report/<int:report_id>", methods=["GET"])
    def edit_report(report_id):
        """Load report data into analyze form for editing."""
        if "user_id" not in session:
            flash("Please login to edit reports", "info")
            return redirect(url_for("login"))
            
        report = Report.query.get_or_404(report_id)
        
        # Verify ownership
        if report.user_id != session["user_id"]:
            flash("You do not have permission to edit this report", "error")
            return redirect(url_for("dashboard"))
            
        user = User.query.get(session["user_id"])
        
        # Render analyze template with report data pre-filled
        return render_template(
            "analyze.html",
            today=date.today().isoformat(),
            profile=user.to_profile_dict(),
            editing_report=report.to_dict() # Pass specific report to edit
        )

    @app.route("/analyze", methods=["GET", "POST"])
    def analyze():
        """Handle form submission and render full report."""
        if "user_id" not in session:
            flash("Please login to access the analysis tool", "info")
            return redirect(url_for("login"))
        
        user_id = session.get("user_id")
        user = User.query.get(user_id)
        
        # Retrieve existing reports
        existing_reports_objs = Report.query.filter_by(user_id=user_id).order_by(Report.test_date).all()
        # Convert to dicts for logic
        existing_reports = [r.to_dict() for r in existing_reports_objs]
        sorted_reports = existing_reports # Already sorted by query
        last_report = sorted_reports[-1] if sorted_reports else None

        if request.method == "GET":
            today_str = date.today().isoformat()
            return render_template(
                "analyze.html",
                today=today_str,
                profile=user.to_profile_dict(),
                last_report=last_report
            )
        
        # --- User profile ---
        name = request.form.get("name") or user.name
        age = int(request.form.get("age") or user.age or 0)
        diabetes_type = request.form.get("diabetes_type") or user.diabetes_type or "TYPE_2"
        height_cm = float(request.form.get("height_cm") or user.height_cm or 0)
        weight_kg = float(request.form.get("weight_kg") or user.weight_kg or 0)
        
        # Check if we are updating an existing report ID (hidden field)
        report_id = request.form.get("report_id")

        # Update profile in DB
        user.name = name
        user.age = age
        user.diabetes_type = diabetes_type
        user.height_cm = height_cm
        user.weight_kg = weight_kg
        db.session.commit()

        # --- Current report ---
        fbs = float(request.form.get("fbs") or 0)
        ppbs = float(request.form.get("ppbs") or 0)
        hba1c = float(request.form.get("hba1c") or 0)
        test_date_str = request.form.get("test_date") or date.today().isoformat()
        
        # Prepare data for API
        data = {
            "user": user.to_profile_dict(),
            "current_report": {
                "fbs": fbs,
                "ppbs": ppbs,
                "hba1c": hba1c,
                "test_date": test_date_str,
            },
        }

        # --- Previous report (Automated) ---
        previous_report = None
        if sorted_reports:
             current_test_date = date.fromisoformat(test_date_str)
             prior_reports = [r for r in sorted_reports if date.fromisoformat(r["test_date"]) < current_test_date]
             
             if prior_reports:
                 previous_report = prior_reports[-1]
             # logic for "same day" or if strictly latest is current
             elif sorted_reports and date.fromisoformat(sorted_reports[-1]["test_date"]) == current_test_date and len(sorted_reports) > 1:
                   # If we are editing the latest report, previous is the one before it
                   if report_id and int(report_id) == sorted_reports[-1]["id"]:
                        previous_report = sorted_reports[-2]
                   else:
                        previous_report = sorted_reports[-2]
             elif sorted_reports and not report_id:
                   # New report, previous is the last one
                   previous_report = sorted_reports[-1]


        if previous_report:
             data["previous_report"] = {
                "fbs": previous_report["fbs"],
                "ppbs": previous_report["ppbs"],
                "hba1c": previous_report["hba1c"],
                "test_date": previous_report["test_date"],
            }
        
        # --- Weekly Progress (Automated) ---
        current_test_date = date.fromisoformat(test_date_str)
        week_start = current_test_date - timedelta(days=6)
        weekly_readings = []
        
        for r in sorted_reports:
            # exclude current report if we are editing it (to avoid double counting if logic was complex, but mapped by date is fine)
            if report_id and int(report_id) == r["id"]:
                continue
                
            r_date = date.fromisoformat(r["test_date"])
            if week_start <= r_date <= current_test_date:
                weekly_readings.append({
                    "date": r_date,
                    "fasting_sugar": r["fbs"],
                    "post_meal_sugar": r["ppbs"],
                })
        
        # Add current (newly submitted) values to weekly progress for the analysis
        weekly_readings.append({
             "date": current_test_date,
             "fasting_sugar": fbs,
             "post_meal_sugar": ppbs,
        })
        
        # Deduplicate by date (latest wins)
        weekly_readings_map = {item['date']: item for item in weekly_readings}
        unique_weekly_readings = list(weekly_readings_map.values())

        if unique_weekly_readings:
            data["weekly_progress"] = {
                "week_start_date": week_start.isoformat(),
                "daily_readings": unique_weekly_readings
            }


        # Use API to generate the comprehensive textual report
        structured_analysis = api.analyze_structured_from_dict(data)
        full_report_text = api.analyze_from_dict(data) # Keep full text for the bottom section

        # Save report to user's history
        target_report = None
        
        if report_id:
            # Update specific report being edited
            target_report = Report.query.get(report_id)
            if target_report and target_report.user_id == user.id:
                target_report.fbs = fbs
                target_report.ppbs = ppbs
                target_report.hba1c = hba1c
                target_report.test_date = date.fromisoformat(test_date_str)
                target_report.timestamp = datetime.utcnow()
                flash("Report updated successfully", "success")
        else:
            # Check if report for this date already exists for this user to avoid duplicates
            existing_report_obj = Report.query.filter_by(user_id=user.id, test_date=date.fromisoformat(test_date_str)).first()
            
            if existing_report_obj:
                # Update existing for that date
                existing_report_obj.fbs = fbs
                existing_report_obj.ppbs = ppbs
                existing_report_obj.hba1c = hba1c
                existing_report_obj.timestamp = datetime.utcnow()
                flash("Existing report for this date updated", "info")
            else:
                new_report = Report(
                    user_id=user.id,
                    fbs=fbs,
                    ppbs=ppbs,
                    hba1c=hba1c,
                    test_date=date.fromisoformat(test_date_str)
                )
                db.session.add(new_report)
                flash("New report generated successfully", "success")
        
        db.session.commit()

        return render_template(
            "report.html",
            full_report=full_report_text,
            structured_analysis=structured_analysis,
            health_summary_heading="Health Summary",
            report_comparison_heading="Report Comparison",
            weekly_progress_heading="Weekly Progress Analysis",
            monthly_progress_heading="Monthly Progress Analysis",
            visual_graph_heading="Visual Graph Explanation",
            weekly_action_heading="Weekly Action Plan",
            monthly_improvement_heading="Monthly Improvement Plan",
            motivation_heading="Motivation Message",
            reassurance_heading="Reassurance Note",
            disclaimer_heading="Medical Disclaimer",
        )

    @app.route("/health_summary", methods=["GET"])
    def health_summary():
        """Show the detailed health summary."""
        if "user_id" not in session:
            flash("Please login to access your health summary", "info")
            return redirect(url_for("login"))
        
        user = User.query.get(session["user_id"])
        
        # Get latest report
        latest_report = Report.query.filter_by(user_id=user.id).order_by(Report.test_date.desc()).first()
        
        if not latest_report:
            flash("No reports found. Please submit a health report first.", "info")
            return redirect(url_for("analyze"))
            
        # Get previous report
        previous_report = Report.query.filter_by(user_id=user.id).filter(Report.test_date < latest_report.test_date).order_by(Report.test_date.desc()).first()
        
        data = {
            "user": user.to_profile_dict(),
            "current_report": latest_report.to_dict(),
        }
        
        if previous_report:
            data["previous_report"] = previous_report.to_dict()
            
        summary_text = api.get_health_summary(data)
        
        # Parse MD to HTML or just pass text? 
        # The user requested 'display this text', implying the formatting. 
        # We'll render it in a template that preserves white-space or renders markdown.
        # Since it uses **bold** and bullets, better to render markdown.
        # But we don't have a markdown filter installed in Flask by default.
        # We can simulate basic formatting in logic or template.
        # For now, let's pass it as text and use a simple markdown parser or just pre-formatted text.
        # Actually, let's look at `report.html` to see how it renders `full_report_text`.
        # It probably uses `| safe` or a markdown filter. 
        
        return render_template("summary.html", summary=summary_text)

    @app.route("/dashboard", methods=["GET"])
    def dashboard():
        """Show user's report history and comparison graphs."""
        if "user_id" not in session:
            flash("Please login to access your dashboard", "info")
            return redirect(url_for("login"))
        
        user_id = session.get("user_id")
        user = User.query.get(user_id)
        
        # Retrieve reports from DB
        reports_objs = Report.query.filter_by(user_id=user_id).order_by(Report.test_date).all()
        sorted_reports = [r.to_dict() for r in reports_objs]
        
        if not sorted_reports:
            flash("No reports found. Submit a report first to see comparisons.", "info")
            return redirect(url_for("analyze"))
        
        # Prepare data for charts
        dates = [report["test_date"] for report in sorted_reports]
        fbs_values = [report["fbs"] for report in sorted_reports]
        ppbs_values = [report["ppbs"] for report in sorted_reports]
        hba1c_values = [report["hba1c"] for report in sorted_reports]
        
        return render_template(
            "dashboard.html",
            reports=sorted_reports,
            dates=json.dumps(dates),
            fbs_values=json.dumps(fbs_values),
            ppbs_values=json.dumps(ppbs_values),
            hba1c_values=json.dumps(hba1c_values),
        )

    @app.route("/translate", methods=["POST"])
    def translate_text():
        """Translate text to target language with chunking for long texts."""
        data = request.get_json()
        text = data.get("text")
        target_lang = data.get("target_lang", "en")
        
        if not text:
            return {"error": "No text provided"}, 400
            
        try:
            translator = GoogleTranslator(source='auto', target=target_lang)
            
            # Helper function to split text into chunks
            def chunk_text(text, limit=4500):
                chunks = []
                current_chunk = ""
                
                # Split by paragraphs first to preserve structure
                paragraphs = text.split('\n\n')
                
                for para in paragraphs:
                    if len(current_chunk) + len(para) < limit:
                        current_chunk += para + "\n\n"
                    else:
                        # If current chunk has content, add it
                        if current_chunk:
                            chunks.append(current_chunk)
                            current_chunk = ""
                        
                        # If the paragraph itself is too long (rare but possible), split by sentences
                        if len(para) > limit:
                            sentences = para.split('. ')
                            for sentence in sentences:
                                if len(current_chunk) + len(sentence) < limit:
                                    current_chunk += sentence + ". "
                                else:
                                    if current_chunk:
                                        chunks.append(current_chunk)
                                    current_chunk = sentence + ". "
                            if current_chunk:
                                current_chunk += "\n\n" # Add paragraph break after processing long para
                        else:
                            current_chunk = para + "\n\n"
                
                if current_chunk:
                    chunks.append(current_chunk)
                return chunks

            # Translate chunks
            translated_parts = []
            chunks = chunk_text(text)
            
            for chunk in chunks:
                if chunk.strip():
                    translated_parts.append(translator.translate(chunk))
                else:
                    translated_parts.append(chunk) # Preserve empty lines if any logic creates them
            
            return {"translated_text": "".join(translated_parts)}

        except Exception as e:
            print(f"Translation Error: {e}") # Log to console
            return {"error": str(e)}, 500

    return app


if __name__ == "__main__":
    application = create_app()
    # Debug can be toggled as needed; host 0.0.0.0 for broader access if required.
    application.run(debug=True)
