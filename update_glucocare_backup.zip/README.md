# GlucoBalance - Digital Health Assistant

GlucoBalance is an empathetic, intelligent, and responsible digital health assistant designed to help diabetic and pre-diabetic patients manage and improve their condition through regular monitoring, progress tracking, motivation, and lifestyle guidance.

## 🎯 Core Philosophy

**GlucoBalance is NOT a replacement for medical professionals.** Instead, it serves as a supportive tool that helps users:
- Understand their health data in simple terms
- Build healthy habits through consistent guidance
- Stay motivated and stress-free
- Track progress over time

## ✨ Key Features

### 1. AI Health Summary
- Summarizes current health condition in simple, easy-to-understand language
- Explains sugar values without medical jargon
- Highlights improvements first, even if small

### 2. Report Comparison & Trend Analysis
- Compares previous vs current reports
- Analyzes weekly and monthly trends
- Identifies patterns (improvement, stability, or need for attention)
- Focuses on trends rather than one-time readings

### 3. Weekly & Monthly Progress Tracking
- Tracks and evaluates short-term and long-term progress
- Classifies progress as:
  - Improving steadily
  - Stable and controlled
  - Needs lifestyle adjustment

### 4. Visual Progress Representation
- Supports visual interpretation through line graphs
- Explains graphs in plain language
- Helps users understand trends and patterns

### 5. Weekly Action Plan
- Generates realistic and achievable weekly plans
- Includes physical activity, diet focus, sleep, and stress management
- Practical, flexible, and stress-free recommendations

### 6. Monthly Improvement Plan
- Structured monthly plan focused on gradual sugar control
- Emphasizes habit consistency
- Addresses mental and emotional well-being
- Includes regular health monitoring

### 7. Motivation & Emotional Support
- Continuously motivates users
- Praises consistency rather than perfection
- Normalizes small fluctuations
- Encourages patience and persistence

### 8. Personalized Suggestions
- Provides 3-5 personalized lifestyle suggestions based on trends
- Covers diet, physical activity, sleep, and stress management
- General, safe, and easy-to-follow recommendations

### 9. Reassurance & Awareness
- Reassures users that diabetes is manageable
- Emphasizes that early and consistent care brings strong results
- Normalizes the journey and reduces fear

### 10. Medical Disclaimer
- Always clearly states that the platform is not a replacement for professional medical advice
- Provides guidance on when to consult a doctor

## 📁 Project Structure

```
update glucocare/
├── models.py                 # Data models (UserProfile, HealthReport, etc.)
├── health_summary.py         # AI Health Summary module
├── trend_analysis.py         # Report Comparison & Trend Analysis
├── progress_tracking.py      # Weekly & Monthly Progress Tracking
├── visual_progress.py        # Visual Progress Representation
├── action_plans.py           # Weekly & Monthly Action Plans
├── motivation.py             # Motivation & Emotional Support
├── suggestions.py            # Personalized Suggestions
├── glucobalance.py          # Main orchestrator class
├── cli.py                    # Command-line interface
├── api.py                    # API wrapper for programmatic access
├── utils.py                  # Utility functions
├── example_usage.py          # Usage examples
├── test_example.py           # Test script
└── README.md                # This file
```

## 🚀 Quick Start

### Method 1: Command-Line Interface (Easiest)

```bash
python cli.py
```

This will guide you through an interactive setup to create your health analysis.

### Method 2: Python API

```python
from api import GlucoBalanceAPI
from datetime import date

# Initialize API
api = GlucoBalanceAPI()

# Create analysis from dictionary
data = {
    "user": {
        "age": 45,
        "diabetes_type": "TYPE_2",
        "height_cm": 170,
        "weight_kg": 75,
        "name": "John Doe"
    },
    "current_report": {
        "fbs": 135.0,
        "ppbs": 185.0,
        "hba1c": 7.2,
        "test_date": "2026-02-09"
    },
    "previous_report": {
        "fbs": 145.0,
        "ppbs": 195.0,
        "hba1c": 7.5,
        "test_date": "2026-01-10"
    }
}

report = api.analyze_from_dict(data)
print(report)
```

### Method 3: Direct Python Usage

```python
from glucobalance import GlucoBalance
from models import AnalysisContext, UserProfile, HealthReport, DiabetesType
from datetime import date

# Create user profile
user = UserProfile(
    age=45,
    diabetes_type=DiabetesType.TYPE_2,
    height_cm=170,
    weight_kg=75,
    name="John Doe"
)

# Create health report
current_report = HealthReport(
    fbs=135.0,
    ppbs=185.0,
    hba1c=7.2,
    test_date=date.today()
)

# Create analysis context
context = AnalysisContext(
    user_profile=user,
    current_report=current_report,
    previous_report=None,  # Optional
    weekly_progress=None,  # Optional
    monthly_summary=None   # Optional
)

# Generate comprehensive analysis
assistant = GlucoBalance()
report = assistant.generate_comprehensive_analysis(context)
print(report)
```

## 📊 Data Models

### UserProfile
- `age`: int
- `diabetes_type`: DiabetesType (TYPE_1, TYPE_2, PRE_DIABETIC, GESTATIONAL)
- `height_cm`: float
- `weight_kg`: float
- `name`: Optional[str]

### HealthReport
- `fbs`: float (Fasting Blood Sugar in mg/dL)
- `ppbs`: float (Post-Prandial Blood Sugar in mg/dL)
- `hba1c`: float (HbA1c percentage)
- `test_date`: date
- `notes`: Optional[str]

### WeeklyProgress
- `week_start_date`: date
- `daily_readings`: List[DailyReading]
- `average_fasting`: Optional[float]
- `average_post_meal`: Optional[float]
- `total_activity_minutes`: Optional[int]
- `average_diet_score`: Optional[float]

### DailyReading
- `date`: date
- `fasting_sugar`: Optional[float]
- `post_meal_sugar`: Optional[float]
- `activity_minutes`: Optional[int]
- `diet_adherence_score`: Optional[float] (0-10 scale)
- `notes`: Optional[str]

## 🔒 Safety & Ethical Guidelines

GlucoBalance follows strict safety and ethical rules:

- ✅ Never claims to instantly cure diabetes
- ✅ Never replaces professional medical advice
- ✅ Always states that diabetes can be controlled and improved with consistency
- ✅ Uses calm, reassuring, and non-alarming language
- ✅ Focuses on habit-based improvement, not fear
- ✅ Always includes medical disclaimer

## 🎨 Output Format

The comprehensive analysis includes:

1. **Health Summary** - Current condition overview
2. **Report Comparison** - Previous vs current comparison
3. **Weekly Progress Analysis** - Short-term progress evaluation
4. **Monthly Progress Analysis** - Long-term progress evaluation
5. **Visual Graph Explanation** - Plain language graph interpretation
6. **Weekly Action Plan** - Practical weekly goals
7. **Monthly Improvement Plan** - Structured monthly approach
8. **Motivation Message** - Personalized encouragement
9. **Suggestions & Next Steps** - Actionable lifestyle recommendations
10. **Reassurance Note** - Positive reinforcement
11. **Medical Disclaimer** - Mandatory safety notice
12. **Future Scope** - Upcoming features (optional)

## 🔮 Future Enhancements

Future versions may include:
- 🤖 AI-based sugar trend prediction
- ⚠️ Early risk alerts
- 👨‍⚕️ Doctor dashboards for monitored care
- 📊 Advanced analytics for long-term patterns
- 🎯 Personalized goal setting
- 📱 Smart reminders

## 📝 Requirements

- Python 3.7+
- Standard library only (no external dependencies)

## 🤝 Contributing

This is a health-focused application. When contributing:
- Always prioritize user safety
- Maintain empathetic and reassuring tone
- Never provide medical advice
- Focus on habit-building and lifestyle guidance
- Test thoroughly with various data scenarios

## ⚠️ Important Notes

- This platform is **NOT a replacement for professional medical advice**
- Always consult your doctor for medication changes or medical concerns
- Use this tool as a supportive companion, not a medical professional
- Individual results may vary
- Focus on consistency and patience in your health journey

## 📄 License

This project is designed for health assistance purposes. Use responsibly and always consult healthcare professionals for medical decisions.

---

**Remember:** Managing diabetes is a journey, and you are moving in the right direction. Every small improvement counts! 🌟
